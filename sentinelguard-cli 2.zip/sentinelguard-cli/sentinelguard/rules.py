from dataclasses import dataclass
import re


@dataclass(frozen=True)
class Rule:
    id: str
    title: str
    severity: str
    pattern: re.Pattern
    remediation: str
    group: int = 0


RULES = (
    Rule("SG001", "Private key material", "critical", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"), "Remove the key from Git history, rotate it, and load it from a secret manager."),
    Rule("SG002", "AWS access key ID", "high", re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"), "Revoke or rotate the credential, then use environment-based credentials."),
    Rule("SG003", "GitHub personal access token", "high", re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{20,}\b"), "Revoke the token in GitHub settings and replace it with a scoped secret."),
    Rule("SG004", "Slack token", "high", re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}\b"), "Revoke the token and store its replacement outside source control."),
    Rule("SG005", "Generic hard-coded secret", "medium", re.compile(r"(?i)\b(?:api[_-]?key|secret|password|token)\s*[:=]\s*['\"]([^'\"\s]{8,})['\"]"), "Move the value to a secret manager or environment variable; rotate if it was real."),
    Rule("SG006", "Debug mode enabled", "medium", re.compile(r"(?i)\b(?:debug|flask_debug|django_debug)\s*[:=]\s*(?:true|1|yes)\b"), "Disable debug mode outside local development."),
    Rule("SG007", "Insecure HTTP URL", "low", re.compile(r"\bhttp://(?!localhost\b|127\.0\.0\.1\b)[^\s'\"]+"), "Use HTTPS for remote services unless there is a documented exception."),
    Rule("SG008", "TLS verification disabled", "high", re.compile(r"(?i)\b(?:verify|ssl_verify)\s*=\s*False\b|\bcurl\s+.*(?:-k|--insecure)\b"), "Enable certificate verification and fix the trust chain instead of bypassing TLS."),
)

SENSITIVE_FILENAMES = {".env", ".env.local", ".env.production", "id_rsa", "id_ed25519", "credentials.json", "service-account.json"}
