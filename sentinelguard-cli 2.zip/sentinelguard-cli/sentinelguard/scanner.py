import json
import math
import os
import re
from dataclasses import asdict, dataclass
from pathlib import Path

from .rules import RULES, SENSITIVE_FILENAMES


@dataclass
class Finding:
    rule_id: str
    title: str
    severity: str
    path: str
    line: int
    preview: str
    remediation: str

    def as_dict(self):
        return asdict(self)


def redact(text: str) -> str:
    clean = " ".join(text.strip().split())
    if len(clean) <= 8: return "[REDACTED]"
    return f"{clean[:4]}…{clean[-4:]}"


def shannon_entropy(value: str) -> float:
    if not value: return 0
    counts = {char: value.count(char) for char in set(value)}
    return -sum((count / len(value)) * math.log2(count / len(value)) for count in counts.values())


class Scanner:
    def __init__(self, root: str, config: dict | None = None):
        self.root = Path(root).resolve()
        self.config = config or {}
        self.exclude = set(self.config.get("exclude", [])) | {".git", "__pycache__", ".pytest_cache"}
        self.allow_rules = set(self.config.get("allow_rules", []))
        self.max_file_size = int(self.config.get("max_file_size", 1_048_576))

    def files(self):
        for base, dirs, names in os.walk(self.root):
            dirs[:] = [d for d in dirs if d not in self.exclude]
            for name in names:
                path = Path(base, name)
                if path.stat().st_size <= self.max_file_size and not self._binary(path):
                    yield path

    @staticmethod
    def _binary(path: Path) -> bool:
        try:
            return b"\0" in path.read_bytes()[:2048]
        except OSError:
            return True

    def scan(self) -> list[Finding]:
        findings = []
        for path in self.files():
            relative = str(path.relative_to(self.root))
            if path.name in SENSITIVE_FILENAMES:
                findings.append(Finding("SG009", "Sensitive file tracked", "high", relative, 1, path.name, "Remove this file from version control, rotate any contents, and use a documented example file instead."))
            try:
                lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
            except OSError:
                continue
            for number, text in enumerate(lines, 1):
                self._match_rules(findings, relative, number, text)
                self._match_entropy(findings, relative, number, text)
        return self._deduplicate(findings)

    def _match_rules(self, findings, path, line, text):
        for rule in RULES:
            if rule.id in self.allow_rules: continue
            match = rule.pattern.search(text)
            if match:
                value = match.group(rule.group)
                findings.append(Finding(rule.id, rule.title, rule.severity, path, line, redact(value), rule.remediation))

    def _match_entropy(self, findings, path, line, text):
        if "SG010" in self.allow_rules or len(text) > 2000: return
        for token in text.replace('"', ' ').replace("'", ' ').split():
            candidate = token.strip("=,:;()[]{}")
            # Token-like identifiers are limited to common credential characters.
            # This avoids treating regular-expression source code as a secret.
            if re.fullmatch(r"[A-Za-z0-9_-]{28,}", candidate) and shannon_entropy(candidate) >= 4.2 and any(char.isdigit() for char in candidate):
                findings.append(Finding("SG010", "High-entropy token", "medium", path, line, redact(candidate), "Review the token. If it is a credential, rotate it and move it to secure configuration."))
                break

    @staticmethod
    def _deduplicate(findings):
        seen, output = set(), []
        for item in findings:
            key = (item.rule_id, item.path, item.line)
            if key not in seen:
                seen.add(key); output.append(item)
        rank = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        return sorted(output, key=lambda f: (rank[f.severity], f.path, f.line))


def load_config(root: str, config_path: str | None = None) -> dict:
    path = Path(config_path) if config_path else Path(root, ".sentinelguard.json")
    if not path.exists(): return {}
    try:
        return json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError(f"Invalid configuration at {path}: {error}") from error
