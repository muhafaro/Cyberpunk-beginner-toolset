import json
from collections import Counter


def text(findings):
    if not findings:
        return "✓ No findings. SentinelGuard scanned without detecting supported secret or configuration patterns."
    rows = ["SentinelGuard findings", "=" * 78]
    for item in findings:
        rows.extend([f"[{item.severity.upper():8}] {item.rule_id}  {item.path}:{item.line}", f"  {item.title} — {item.preview}", f"  Fix: {item.remediation}", ""])
    counts = Counter(f.severity for f in findings)
    rows.append("Summary: " + ", ".join(f"{count} {severity}" for severity, count in sorted(counts.items())))
    return "\n".join(rows)


def json_report(findings):
    return json.dumps({"tool": "SentinelGuard", "findings": [f.as_dict() for f in findings]}, indent=2)


def sarif(findings):
    levels = {"critical": "error", "high": "error", "medium": "warning", "low": "note"}
    rules = {}
    results = []
    for finding in findings:
        rules[finding.rule_id] = {"id": finding.rule_id, "shortDescription": {"text": finding.title}, "help": {"text": finding.remediation}}
        results.append({"ruleId": finding.rule_id, "level": levels[finding.severity], "message": {"text": finding.title}, "locations": [{"physicalLocation": {"artifactLocation": {"uri": finding.path}, "region": {"startLine": finding.line}}}]})
    return json.dumps({"$schema": "https://json.schemastore.org/sarif-2.1.0.json", "version": "2.1.0", "runs": [{"tool": {"driver": {"name": "SentinelGuard", "rules": list(rules.values())}}, "results": results}]}, indent=2)
