import argparse
import sys
from pathlib import Path

from . import __version__
from .reporters import json_report, sarif, text
from .scanner import Scanner, load_config


def parser():
    p = argparse.ArgumentParser(prog="sentinelguard", description="Local-first repository secret and configuration scanner.")
    p.add_argument("--version", action="version", version=f"SentinelGuard {__version__}")
    subs = p.add_subparsers(dest="command", required=True)
    for name in ("scan", "pre-commit"):
        sub = subs.add_parser(name, help="Scan a directory" if name == "scan" else "Scan staged paths passed by a Git hook")
        sub.add_argument("path", nargs="?", default=".")
        sub.add_argument("--format", choices=("text", "json", "sarif"), default="text")
        sub.add_argument("--config", help="Path to a JSON configuration file")
        sub.add_argument("--fail-on", choices=("critical", "high", "medium", "low", "none"), default="high", help="Exit 1 at or above this severity")
    return p


def main(argv=None):
    args = parser().parse_args(argv)
    root = Path(args.path)
    if not root.exists():
        print(f"Error: path does not exist: {root}", file=sys.stderr); return 2
    try:
        findings = Scanner(str(root), load_config(str(root), args.config)).scan()
    except ValueError as error:
        print(f"Error: {error}", file=sys.stderr); return 2
    output = {"text": text, "json": json_report, "sarif": sarif}[args.format](findings)
    print(output)
    levels = ["critical", "high", "medium", "low"]
    if args.fail_on != "none" and any(levels.index(f.severity) <= levels.index(args.fail_on) for f in findings): return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
