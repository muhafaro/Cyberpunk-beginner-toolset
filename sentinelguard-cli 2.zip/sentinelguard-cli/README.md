# SentinelGuard

**SentinelGuard** is a local-first command-line scanner for Git repositories. It identifies likely exposed credentials, sensitive filenames, and a focused set of risky configuration patterns—without sending your source code anywhere.

> This is a lightweight defensive tool, not a replacement for professional secret management, code review, dependency scanning, or incident response.

## What it checks

- Private key headers, AWS key IDs, GitHub tokens, and Slack tokens
- Generic hard-coded `password`, `secret`, `token`, and `api_key` assignments
- High-entropy token-like strings
- Accidentally tracked `.env`, SSH key, credential, and service-account files
- Debug mode, TLS verification bypasses, and plain HTTP remote URLs

Findings show a **redacted preview** only; SentinelGuard does not print suspected full credential values.

## Installation

Requires Python 3.10+.

```bash
git clone https://github.com/YOUR_USERNAME/sentinelguard.git
cd sentinelguard
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Scan a project

```bash
sentinelguard scan /path/to/project
sentinelguard scan . --format json
sentinelguard scan . --format sarif > sentinelguard.sarif
```

The command exits with code `1` for `high` or `critical` findings by default—useful in CI. Adjust it when needed:

```bash
sentinelguard scan . --fail-on critical
sentinelguard scan . --fail-on none
```

## Configuration

The optional `.sentinelguard.json` in a scanned project controls exclusions and accepted rules:

```json
{
  "exclude": ["generated", "third_party"],
  "allow_rules": ["SG007"],
  "max_file_size": 1048576
}
```

Use `allow_rules` sparingly and document why an exception is safe.

## Pre-commit hook

Create `.git/hooks/pre-commit` in the project you want to protect:

```sh
#!/bin/sh
sentinelguard scan . --fail-on high
```

Then make it executable:

```bash
chmod +x .git/hooks/pre-commit
```

## Example output

```text
[HIGH    ] SG009  .env:1
  Sensitive file tracked — .env
  Fix: Remove this file from version control, rotate any contents, and use a documented example file instead.
```

## Development

```bash
pip install pytest
pytest -q
```

## Architecture

```text
Repository → file filtering → rule + entropy checks → redacted findings → text / JSON / SARIF
```

## Responsible use

Run this only on repositories and files you are authorized to inspect. If a real secret is found, immediately revoke or rotate it; deleting the visible line alone does not remove it from Git history.
