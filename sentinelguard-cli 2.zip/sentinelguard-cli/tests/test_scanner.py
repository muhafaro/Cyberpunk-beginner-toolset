from pathlib import Path

from sentinelguard.scanner import Scanner, redact


def test_scanner_detects_and_redacts_github_token(tmp_path: Path):
    token = "ghp_" + "a" * 32
    (tmp_path / "app.py").write_text(f"token = '{token}'\n")
    findings = Scanner(str(tmp_path)).scan()
    assert findings[0].rule_id == "SG003"
    assert token not in findings[0].preview


def test_scanner_detects_sensitive_env_file(tmp_path: Path):
    (tmp_path / ".env").write_text("HELLO=world\n")
    assert any(f.rule_id == "SG009" for f in Scanner(str(tmp_path)).scan())


def test_scanner_respects_rule_allow_list(tmp_path: Path):
    (tmp_path / "a.py").write_text("debug = True\n")
    assert not [f for f in Scanner(str(tmp_path), {"allow_rules": ["SG006"]}).scan() if f.rule_id == "SG006"]


def test_redact_never_returns_full_value():
    assert "verylongsecret" not in redact("verylongsecretvalue")
